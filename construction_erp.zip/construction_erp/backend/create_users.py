from app import create_app, db
from app.models.user import User

app = create_app()

with app.app_context():
    user1 = User(name="Owner", email="owner@test.com", password="1234", role="owner")
    user2 = User(name="Engineer", email="engineer@test.com", password="1234", role="engineer")
    user3 = User(name="Labor", email="labor@test.com", password="1234", role="labor")
    user4 = User(name="Client", email="client@test.com", password="1234", role="client")

    db.session.add_all([user1, user2, user3, user4])
    db.session.commit()

print("Users inserted successfully!")
