from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_user, logout_user
from app.models.user import User

auth = Blueprint("auth", __name__)

@auth.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()

        if user and user.password == password:
            login_user(user)

            # Role-based redirect
            if user.role == "owner":
                return redirect("/owner")
            elif user.role == "engineer":
                return redirect("/engineer")
            elif user.role == "labor":
                return redirect("/labor")
            elif user.role == "client":
                return redirect("/client")

        return "Invalid Credentials"

    return render_template("login.html")


@auth.route("/logout")
def logout():
    logout_user()
    return redirect("/login")
