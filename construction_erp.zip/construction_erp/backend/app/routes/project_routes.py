from flask import Blueprint, render_template, request, redirect
from flask_login import login_required, current_user
from app.models.project import Project
from app import db

project = Blueprint("project", __name__)

@project.route("/create_project", methods=["GET", "POST"])
@login_required
def create_project():
    if current_user.role != "owner":
        return "Access Denied"

    if request.method == "POST":
        name = request.form.get("name")
        location = request.form.get("location")
        budget = request.form.get("budget")

        new_project = Project(
            name=name,
            location=location,
            budget=budget,
            status="Active"
        )

        db.session.add(new_project)
        db.session.commit()

        return redirect("/owner")

    return render_template("create_project.html")
