from flask import Blueprint, render_template
from flask_login import login_required, current_user

dashboard = Blueprint("dashboard", __name__)

from app.models.project import Project

@dashboard.route("/owner")
@login_required
def owner_dashboard():
    if current_user.role != "owner":
        return "Access Denied"

    projects = Project.query.all()

    return render_template("owner_dashboard.html", projects=projects)
from app.models.project import Project
from app.models.task import Task
@dashboard.route("/engineer")
@login_required
def engineer_dashboard():
    if current_user.role != "engineer":
        return "Access Denied"

    projects = Project.query.all()
    tasks = Task.query.all()

    return render_template(
        "engineer_dashboard.html",
        projects=projects,
        tasks=tasks
    )



@dashboard.route("/labor")
@login_required
def labor_dashboard():
    if current_user.role != "labor":
        return "Access Denied"
    return render_template("labor_dashboard.html")


@dashboard.route("/client")
@login_required
def client_dashboard():
    if current_user.role != "client":
        return "Access Denied"
    return render_template("client_dashboard.html")
