from app import db

class Project(db.Model):
    __tablename__ = "projects"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    location = db.Column(db.String(200))
    budget = db.Column(db.Float)
    status = db.Column(db.String(50))

    tasks = db.relationship("Task", backref="project", lazy=True)

    def calculate_progress(self):
        if not self.tasks:
            return 0

        total = sum(task.progress for task in self.tasks)
        return total // len(self.tasks)
